
Plugin Name: Auto Watermark
Plugin URI: http://cn.aliceding.com/wordpressplugins/autowatermark
Description: This plugin help people add watermarks to the images automatically.
Version: 1.1
Author:Alice Ding
Author URI: http://cn.aliceding.com
Requires at least: 3.9
Tested up to: 4.9.3
License: GPLv2
Tags: watermark, image, add watermark

Copyright (c) cn.aliceding.com

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR

== Plugin Description ==

This plugin help people add watermarks to the images automatically

== Installation ==
Go to your website backend, click “Plugins”, then “Add New” and upload the zip files
== Frequently Asked Questions ==
n/a
== Screenshots ==
n/a
== Changelog ==

= 1.1 =
* Fix some php and javascripts to make it compatible with the latest wordpress version